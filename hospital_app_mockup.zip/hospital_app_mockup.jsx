import React, { useEffect, useMemo, useRef, useState } from "react";

/*********************** Hospital App – Full (Demo data) ***********************
- Login → filter → patient table → detail popup
- Popup aligned with filter top, width 75vw, close on outside click
- Tabs: Prijímacia správa | Denné záznamy | Laboratórne vyšetrenia | Zobrazovacie vyšetrenia | Prepúšťacia správa | Epikríza
- Denné záznamy: table list ("Denný záznam – Deň X" + dátum); click to expand the selected day below
- Labs merged; 2nd-level categories: Biochemické | Hematologické | Koagulačné | Imunologické | Genetické | Mikrobiologické | Cytologické a histologické
- Imaging sub-tabs centered: RTG | USG | CT | MR (no "poznámka" column)
- No alias imports; UI shims for sandbox reliability
******************************************************************************/

/**************************** THEME ****************************/
const COLORS = {
  primary: "#8C3253",
  secondary: "#8C566A",
  accent: "#BF95A5",
  light: "#F2D5E0",
  bg: "#F2F2F2",
  text: "#1E1E1E",
  border: "#E5E7EB",
  danger: "#C62828",
};

const LOGO_URL =
  "https://raw.githubusercontent.com/JakubGazdaCortexVision/CV/7cc97befa6e2d29530a9f7389098a9bb539ea370/logo_app.svg";

/**************************** UI SHIMS ****************************/
function Card({ children, className = "", style = {} }) {
  return (
    <div className={`rounded-2xl shadow-sm border bg-white ${className}`} style={{ borderColor: COLORS.border, ...style }}>{children}</div>
  );
}
function CardContent({ children, className = "" }) { return <div className={className}>{children}</div>; }
function Button({ children, onClick, variant = "solid", className = "", style = {}, type = "button" }) {
  const base = variant === "outline" ? "border text-slate-700 hover:bg-slate-50" : "text-white";
  const bg = variant === "outline" ? {} : { background: COLORS.primary };
  return (
    <button type={type} onClick={onClick} className={`px-3 py-2 rounded-xl transition ${base} ${className}`} style={{ borderColor: COLORS.border, ...bg, ...style }}>{children}</button>
  );
}
function Input({ className = "", ...props }) { return <input className={`px-3 py-2 rounded-xl border outline-none w-full ${className}`} style={{ borderColor: COLORS.border }} {...props} />; }
function Label({ children }) { return <label className="text-sm text-slate-700 block mb-1">{children}</label>; }
function Table({ children }) { return <table className="w-full text-sm">{children}</table>; }
function TableHeader({ children }) { return <thead>{children}</thead>; }
function TableBody({ children }) { return <tbody>{children}</tbody>; }
function TableRow({ children, className = "", onClick }) { return <tr className={className} onClick={onClick}>{children}</tr>; }
function TableHead({ children, className = "" }) { return <th className={`text-left px-3 py-2 border-b ${className}`} style={{ borderColor: COLORS.border }}>{children}</th>; }
function TableCell({ children, className = "" }) { return <td className={`px-3 py-2 border-t ${className}`} style={{ borderColor: COLORS.border }}>{children}</td>; }
function Badge({ children }) { return <span className="px-2 py-1 text-xs border rounded-xl" style={{ borderColor: COLORS.border, background: `${COLORS.light}55`, color: COLORS.primary }}>{children}</span>; }
function TabsTrigger({ value, current, onClick, children }) {
  const active = current === value;
  return (
    <button onClick={() => onClick(value)} className={`px-3 py-1.5 rounded-lg border text-sm ${active ? "bg-white" : "bg-slate-50"}`} style={{ borderColor: COLORS.border, color: active ? COLORS.primary : COLORS.secondary }}>{children}</button>
  );
}
function TabsContent({ value, current, children, className = "" }) { if (value !== current) return null; return <div className={className}>{children}</div>; }

/**************************** HELPERS ****************************/
function withinRef(v, low, high) {
  if (v === null || v === undefined || Number.isNaN(Number(v))) return true;
  const n = Number(v);
  return n >= low && n <= high;
}

/**************************** SEED DATA ****************************/
const PACIENTI = [
  { id: "9254178541", meno: "Ján Kováč", vek: 68, pohlavie: "M", klinika: "I. interná klinika", oddelenie: "Koronárna jednotka", diagnoza: "STEMI anteroseptálne",
    prijimacia: `Pacient prijatý pre náhle vzniknuté bolesti na hrudníku, dušnosť a potenie. EKG: elevácie ST v prekordiálnych zvodoch V2–V4. Troponín výrazne zvýšený. Zahájená DAPT, heparín, urgentný prevoz na katetrizačnú sálu.`,
    disch: `Po PCI stabilizovaný, bez recidívy bolesti. Terapia pri prepustení: DAPT (ASA + ticagrelor), betablokátor, ACEi, statín. Kontrola o 4 týždne.`,
    admits: [{ date: "2025-10-22 07:30", clinic: "I. interná klinika", text: "Prijatie pre bolesti na hrudníku, ST elevácie V2–V4, troponín ↑." }],
    discharges: [{ date: "2025-10-24 15:10", clinic: "I. interná klinika", text: "Po PCI stabilizovaný, DAPT, BB, ACEi, statín." }],
    daily: [
      { day: 1, date: "2025-10-22", type: "status", text: "Bez bolesti, hemodynamicky stabilný." },
      { day: 1, date: "2025-10-22", type: "ordinacia", text: "ASA + ticagrelor, heparín; O2 podľa potreby." },
      { day: 2, date: "2025-10-23", type: "liečba", text: "Betablokátor titrácia, ACEi nasadený." },
      { day: 3, date: "2025-10-24", type: "status", text: "Mobilný, dobre toleruje záťaž." },
    ],
    labsText: [ { date: "2025-10-22 13:30", lab: "Mikrobiológia", text: "Hemokultúry negatívne." } ],
    imaging: [ { date: "2025-10-22 11:00", type: "RTG hrudníka" }, { date: "2025-10-22 07:40", type: "Echo srdca" } ],
  },
  { id: "8410024576", meno: "Eva Novotná", vek: 59, pohlavie: "Ž", klinika: "Gastroenterologická klinika", oddelenie: "Hepatologické odd.", diagnoza: "Cirrhóza pečene Child–Pugh B s ascitom",
    prijimacia: `Pacientka prijatá pre progresívnu distenziu brucha, únavu a periférne opuchy. USG: voľná tekutina v dutine brušnej.`,
    disch: `Po evakuačnej paracentéze a albumíne stabilizovaná. Diéta s obmedzením Na, spironolaktón + furosemid, kontrola v hepatologickej ambulancii.`,
    admits: [{ date: "2025-09-12 09:00", clinic: "Gastroenterologická klinika", text: "Progresia ascitu, hyponatriémia." }],
    discharges: [{ date: "2025-09-16 13:30", clinic: "Gastroenterologická klinika", text: "Po paracentéze stabilizovaná, diéta, diuretiká." }],
    daily: [
      { day: 1, date: "2025-09-12", type: "status", text: "Distenzia brucha, edémy DK." },
      { day: 1, date: "2025-09-12", type: "ordinacia", text: "Paracentéza, albumín, spironolaktón, furosemid." },
      { day: 2, date: "2025-09-13", type: "liečba", text: "Kontrola diurézy, úprava dávok." },
    ],
    labsText: [ { date: "2025-09-12 13:00", lab: "Cytológia ascitu", text: "Bez známok malignity, PMN 180/µL." }, { date: "2025-09-12 10:00", lab: "Mikrobiológia", text: "Kultivácia ascitu negatívna." } ],
    imaging: [ { date: "2025-09-12 09:00", type: "USG brucha" } ],
  },
];

// Numeric lab groups (pivot)
const LAB_GROUPS = {
  chem: {
    params: [
      { key: "ALT", unit: "µkat/L", low: 0.1, high: 1.2 },
      { key: "AST", unit: "µkat/L", low: 0.1, high: 1.0 },
      { key: "CRP", unit: "mg/L", low: 0, high: 5 },
      { key: "Kreatinín", unit: "µmol/L", low: 60, high: 110 },
      { key: "Urea", unit: "mmol/L", low: 2.5, high: 7.5 },
      { key: "Glykémia", unit: "mmol/L", low: 3.9, high: 5.6 },
      { key: "Na", unit: "mmol/L", low: 135, high: 145 },
      { key: "K", unit: "mmol/L", low: 3.5, high: 5.0 },
    ],
    rows: [
      { date: "2025-10-22 08:00", values: { ALT: 1.75, AST: 0.55, CRP: 7.2, Kreatinín: 118, Urea: 8.1, Glykémia: 6.4, Na: 139, K: 4.1 } },
      { date: "2025-10-21 12:00", values: { ALT: 0.9, AST: 0.44, CRP: 4.2, Kreatinín: 102, Urea: 6.9, Glykémia: 5.1, Na: 142, K: 3.2 } },
      { date: "2025-10-20 07:50", values: { ALT: 0.6, AST: 0.38, CRP: 2.1, Kreatinín: 96, Urea: 5.5, Glykémia: 5.6, Na: 140, K: 3.7 } },
      { date: "2025-10-19 13:10", values: { ALT: 0.5, AST: 0.31, CRP: 1.2, Kreatinín: 88, Urea: 4.8, Glykémia: 4.9, Na: 141, K: 4.6 } },
    ],
  },
  ko: {
    params: [
      { key: "Hemoglobín", unit: "g/L", low: 120, high: 160 },
      { key: "Leukocyty", unit: "×10^9/L", low: 4.0, high: 10.0 },
      { key: "Trombocyty", unit: "×10^9/L", low: 150, high: 400 },
      { key: "Erytrocyty", unit: "×10^12/L", low: 4.0, high: 5.8 },
      { key: "Hematokrit", unit: "%", low: 36, high: 48 },
    ],
    rows: [
      { date: "2025-10-22 08:00", values: { Hemoglobín: 137, Leukocyty: 9.8, Trombocyty: 210, Erytrocyty: 4.7, Hematokrit: 42 } },
      { date: "2025-10-21 12:00", values: { Hemoglobín: 121, Leukocyty: 12.4, Trombocyty: 165, Erytrocyty: 4.1, Hematokrit: 36 } },
      { date: "2025-10-20 07:50", values: { Hemoglobín: 118, Leukocyty: 7.5, Trombocyty: 149, Erytrocyty: 3.9, Hematokrit: 35 } },
      { date: "2025-10-19 13:10", values: { Hemoglobín: 126, Leukocyty: 6.2, Trombocyty: 180, Erytrocyty: 4.2, Hematokrit: 37 } },
    ],
  },
  koag: {
    params: [
      { key: "INR", unit: "", low: 0.9, high: 1.2 },
      { key: "aPTT", unit: "s", low: 26, high: 36 },
      { key: "Fibrinogén", unit: "g/L", low: 2.0, high: 4.0 },
      { key: "D-diméry", unit: "mg/L FEU", low: 0.0, high: 0.5 },
    ],
    rows: [
      { date: "2025-10-22 08:00", values: { INR: 1.1, aPTT: 32, Fibrinogén: 2.4, "D-diméry": 0.62 } },
      { date: "2025-10-21 12:00", values: { INR: 1.3, aPTT: 30, Fibrinogén: 3.1, "D-diméry": 0.48 } },
      { date: "2025-10-20 07:50", values: { INR: 1.0, aPTT: 27, Fibrinogén: 2.8, "D-diméry": 0.36 } },
      { date: "2025-10-19 13:10", values: { INR: 0.9, aPTT: 29, Fibrinogén: 3.3, "D-diméry": 0.22 } },
    ],
  },
  immun: {
    params: [
      { key: "IgG", unit: "g/L", low: 7.0, high: 16.0 },
      { key: "IgA", unit: "g/L", low: 0.7, high: 4.0 },
      { key: "IgM", unit: "g/L", low: 0.4, high: 2.3 },
    ],
    rows: [
      { date: "2025-10-22 08:00", values: { IgG: 9.8, IgA: 1.9, IgM: 0.7 } },
      { date: "2025-10-21 12:00", values: { IgG: 17.2, IgA: 2.1, IgM: 0.5 } },
      { date: "2025-10-20 07:50", values: { IgG: 8.6, IgA: 1.5, IgM: 0.9 } },
      { date: "2025-10-19 13:10", values: { IgG: 7.1, IgA: 0.9, IgM: 1.2 } },
    ],
  },
};

/**************************** SUB-VIEWS ****************************/
function LabPivotTable({ groupKey }) {
  const meta = LAB_GROUPS[groupKey];
  const rows = [...meta.rows].sort((a, b) => b.date.localeCompare(a.date));
  return (
    <div className="mt-3">
      <div className="border rounded-xl overflow-auto" style={{ borderColor: COLORS.border, maxHeight: 360 }}>
        <table className="w-full text-sm">
          <thead style={{ position: "sticky", top: 0, zIndex: 1 }}>
            <tr style={{ background: COLORS.light }}>
              <th className="text-left px-3 py-2 border-b" style={{ borderColor: COLORS.border, minWidth: 180 }}>Dátum/čas odberu</th>
              {meta.params.map((p) => (
                <th key={p.key} className="text-left px-3 py-2 border-b" style={{ borderColor: COLORS.border, whiteSpace: "nowrap" }}>
                  <div className="font-semibold text-slate-800">{p.key} {p.unit ? `(${p.unit})` : ""}</div>
                  <div className="text-xs text-slate-500">[{p.low}–{p.high}]</div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, idx) => (
              <tr key={idx} className="hover:bg-slate-50">
                <td className="px-3 py-2 font-semibold" style={{ color: COLORS.primary }}>{r.date}</td>
                {meta.params.map((p) => {
                  const val = r.values[p.key];
                  const out = val !== undefined && !withinRef(val, p.low, p.high);
                  return (
                    <td key={p.key} className="px-3 py-2 border-t" style={{ borderColor: COLORS.border }}>
                      {val === undefined || val === null || val === "" ? (
                        <span className="text-slate-400">—</span>
                      ) : (
                        <span className={out ? "font-semibold" : ""} style={{ color: out ? COLORS.danger : COLORS.text }}>
                          {val}{out ? (Number(val) > p.high ? "↑" : Number(val) < p.low ? "↓" : "") : ""}
                        </span>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/**************************** APP ****************************/
export default function HospitalAppMock() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [queryKlinika, setQueryKlinika] = useState("");
  const [queryOdd, setQueryOdd] = useState("");

  const [open, setOpen] = useState(false);
  const [sel, setSel] = useState(null);

  const [mainTab, setMainTab] = useState("admit"); // admit | denne | labs | imaging | discharge | epik
  const [labSubTab, setLabSubTab] = useState("biochem"); // biochem | hemato | koag | immun | genet | mikro | cytohisto
  const [imagingSubTab, setImagingSubTab] = useState("rtg"); // rtg | usg | ct | mr
  const [expandedDay, setExpandedDay] = useState(null);

  // Align dialog top with filter's top and allow outside click to close
  const filterRef = useRef(null);
  const [dialogTop, setDialogTop] = useState(80);
  useEffect(() => {
    const recalc = () => {
      const rect = filterRef.current?.getBoundingClientRect();
      if (rect) setDialogTop(rect.top + window.scrollY);
    };
    recalc();
    window.addEventListener("resize", recalc);
    window.addEventListener("scroll", recalc);
    return () => { window.removeEventListener("resize", recalc); window.removeEventListener("scroll", recalc); };
  }, []);

  const filtered = useMemo(() => {
    return PACIENTI.filter((p) =>
      (!queryKlinika || p.klinika.toLowerCase().includes(queryKlinika.toLowerCase())) &&
      (!queryOdd || p.oddelenie.toLowerCase().includes(queryOdd.toLowerCase()))
    );
  }, [queryKlinika, queryOdd]);

  function openDetail(p) { setSel(p); setOpen(true); setMainTab("admit"); setLabSubTab("biochem"); setImagingSubTab("rtg"); setExpandedDay(null); }

  // Close on outside click
  function Overlay({ children }) {
    return (
      <div className="fixed inset-0 bg-black/30 z-40" onClick={(e)=>{ if (e.target === e.currentTarget) setOpen(false); }}>
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: COLORS.bg, color: COLORS.text }}>
      <link rel="icon" type="image/svg+xml" href={LOGO_URL} />

      {/* STATUS BAR */}
      <div className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur supports-backdrop-blur:border-b border-b" style={{ borderColor: COLORS.border }}>
        <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={LOGO_URL} width={28} height={28} alt="Cortex Vision" />
            <div className="text-sm font-medium text-slate-700">Cortex Vision Hospital Suite</div>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-600">
            {loggedIn ? `Dr. ${username}` : "Guest"}
            {loggedIn && (
              <Button variant="outline" onClick={()=>setLoggedIn(false)} className="rounded-lg" style={{ color: COLORS.primary }}>Odhlásiť sa</Button>
            )}
          </div>
        </div>
      </div>

      {/* LOGIN */}
      {!loggedIn ? (
        <div className="min-h-[calc(100vh-56px)] grid place-items-center px-4 py-10">
          <Card className="w-full max-w-md"><CardContent className="p-6 flex flex-col items-center gap-5">
            <img src={LOGO_URL} width={80} height={80} alt="Logo" />
            <h1 className="text-2xl font-semibold text-slate-800 text-center">Cortex Vision Hospital Suite</h1>
            <form className="w-full space-y-4" onSubmit={(e)=>{e.preventDefault(); setLoggedIn(true);}}>
              <div><Label>Username</Label><Input value={username} onChange={(e)=>setUsername(e.target.value)} placeholder="meno.priezvisko" /></div>
              <div><Label>Password</Label><Input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="••••••••" /></div>
              <Button type="submit" className="w-full">Prihlásiť sa</Button>
            </form>
          </CardContent></Card>
        </div>
      ) : (
        <div className="max-w-6xl mx-auto px-4 py-6 grid gap-4">
          {/* FILTER BAR */}
          <Card ref={filterRef}><CardContent className="p-4">
            <h3 className="text-lg font-semibold mb-4 text-slate-800">Filter pacientov</h3>
            <div className="grid md:grid-cols-4 gap-3">
              <Input placeholder="Klinika" value={queryKlinika} onChange={(e)=>setQueryKlinika(e.target.value)} />
              <Input placeholder="Oddelenie" value={queryOdd} onChange={(e)=>setQueryOdd(e.target.value)} />
              <div className="px-3 py-2 rounded-xl border bg-white flex items-center gap-2 w-full" style={{ borderColor: COLORS.border }}>
                <span className="text-slate-500 text-sm">Od</span>
                <input type="date" className="outline-none w-full" />
              </div>
              <div className="px-3 py-2 rounded-xl border bg-white flex items-center gap-2 w-full" style={{ borderColor: COLORS.border }}>
                <span className="text-slate-500 text-sm">Do</span>
                <input type="date" className="outline-none w-full" />
              </div>
            </div>
          </CardContent></Card>

          {/* PATIENTS TABLE */}
          <Card><CardContent className="p-4">
            <h3 className="text-lg font-semibold mb-4 text-slate-800">Zoznam pacientov</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID pacienta</TableHead>
                  <TableHead>Meno</TableHead>
                  <TableHead>Vek</TableHead>
                  <TableHead>Pohlavie</TableHead>
                  <TableHead>Klinika</TableHead>
                  <TableHead>Oddelenie</TableHead>
                  <TableHead>Diagnóza</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((p) => (
                  <TableRow key={p.id} className="hover:bg-slate-50 cursor-pointer" onClick={()=>openDetail(p)}>
                    <TableCell className="font-medium text-slate-800">{p.id}</TableCell>
                    <TableCell>{p.meno}</TableCell>
                    <TableCell>{p.vek}</TableCell>
                    <TableCell>{p.pohlavie}</TableCell>
                    <TableCell>{p.klinika}</TableCell>
                    <TableCell>{p.oddelenie}</TableCell>
                    <TableCell>{p.diagnoza}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </div>
      )}

      {/* DETAIL DIALOG */}
      {open && sel && (
        <Overlay>
          <div className="fixed left-1/2 -translate-x-1/2 z-50" style={{ top: dialogTop }}>
            <div className="relative bg-white border rounded-2xl shadow-lg p-0 w-[75vw] max-h-[80vh] overflow-y-auto" style={{ borderColor: COLORS.border }}>
              <div className="px-6 pt-6 pb-3 border-b" style={{ borderColor: COLORS.border }}>
                <div className="flex items-center justify-between">
                  <div className="text-lg font-semibold text-slate-800">Prehľad informácií o pacientovi – {sel?.meno} ({sel?.id})</div>
                  <Button variant="outline" onClick={()=>setOpen(false)} className="rounded-lg" style={{ color: COLORS.primary }}>Zavrieť</Button>
                </div>
              </div>

              <div className="p-6">
                {/* MAIN TABS */}
                <div className="grid grid-cols-2 md:grid-cols-6 gap-2 rounded-xl bg-slate-50 border mb-3 p-2" style={{ borderColor: COLORS.border }}>
                  {[
                    { key: "admit", label: "Prijímacia správa" },
                    { key: "denne", label: "Denné záznamy" },
                    { key: "labs", label: "Laboratórne vyšetrenia" },
                    { key: "imaging", label: "Zobrazovacie vyšetrenia" },
                    { key: "discharge", label: "Prepúšťacia správa" },
                    { key: "epik", label: "Epikríza" },
                  ].map(t => (
                    <TabsTrigger key={t.key} value={t.key} current={mainTab} onClick={setMainTab}>{t.label}</TabsTrigger>
                  ))}
                </div>

                {/* PRIJÍMACIA SPRÁVA – single record, no filters */}
                <TabsContent value="admit" current={mainTab}>
                  <Card><CardContent className="p-4">
                    <div className="text-sm text-slate-500">{sel?.admits?.[0]?.date || "—"}</div>
                    <pre className="whitespace-pre-wrap text-sm leading-6 text-slate-700">{sel?.admits?.[0]?.text || sel?.prijimacia || "—"}</pre>
                  </CardContent></Card>
                </TabsContent>

                {/* DENNÉ ZÁZNAMY – table of days; click row to expand below */}
                <TabsContent value="denne" current={mainTab}>
                  <Card className="mb-3"><CardContent className="p-0 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[#F2D5E0] text-[#8C3253]">
                          <TableHead className="p-2">Denný záznam</TableHead>
                          <TableHead className="p-2">Dátum</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {Array.from(new Set((sel?.daily||[]).map(d=>d.day)))
                          .sort((a,b)=>a-b)
                          .map(day => {
                            const dayDate = (sel?.daily||[]).find(d=>d.day===day)?.date || "—";
                            return (
                              <TableRow key={day} className="cursor-pointer hover:bg-[#F2D5E0]/30" onClick={()=> setExpandedDay(expandedDay===day? null : day)}>
                                <TableCell className="p-2">{`Denný záznam – Deň ${day}`}</TableCell>
                                <TableCell className="p-2">{dayDate}</TableCell>
                              </TableRow>
                            );
                          })}
                      </TableBody>
                    </Table>
                  </CardContent></Card>

                  {expandedDay !== null && (
                    <Card><CardContent className="p-4">
                      <div className="text-sm text-slate-500 mb-2">Deň {expandedDay}</div>
                      <div className="space-y-2">
                        {(sel?.daily||[])
                          .filter(d=> d.day === expandedDay)
                          .map((d,i)=> (
                            <div key={`${expandedDay}-${i}`} className="p-3 rounded-lg border" style={{ borderColor: COLORS.border }}>
                              <div className="text-xs text-slate-500">{d.date} • {d.type.toUpperCase()}</div>
                              <div className="whitespace-pre-wrap text-slate-800">{d.text}</div>
                            </div>
                          ))}
                      </div>
                    </CardContent></Card>
                  )}
                </TabsContent>

                {/* LABS (merged) */}
                <TabsContent value="labs" current={mainTab}>
                  <div className="flex flex-wrap justify-center gap-2 mb-2 text-sm">
                    <TabsTrigger value="biochem" current={labSubTab} onClick={setLabSubTab}>Biochemické vyšetrenia</TabsTrigger>
                    <TabsTrigger value="hemato" current={labSubTab} onClick={setLabSubTab}>Hematologické vyšetrenia</TabsTrigger>
                    <TabsTrigger value="koag" current={labSubTab} onClick={setLabSubTab}>Koagulačné vyšetrenia</TabsTrigger>
                    <TabsTrigger value="immun" current={labSubTab} onClick={setLabSubTab}>Imunologické vyšetrenia</TabsTrigger>
                    <TabsTrigger value="genet" current={labSubTab} onClick={setLabSubTab}>Genetické vyšetrenia</TabsTrigger>
                    <TabsTrigger value="mikro" current={labSubTab} onClick={setLabSubTab}>Mikrobiologické vyšetrenia</TabsTrigger>
                    <TabsTrigger value="cytohisto" current={labSubTab} onClick={setLabSubTab}>Cytologické a histologické vyšetrenia</TabsTrigger>
                  </div>

                  {labSubTab === "biochem" && <LabPivotTable groupKey="chem" />}
                  {labSubTab === "hemato" && <LabPivotTable groupKey="ko" />}
                  {labSubTab === "koag" && <LabPivotTable groupKey="koag" />}
                  {labSubTab === "immun" && <LabPivotTable groupKey="immun" />}

                  {(labSubTab === "genet" || labSubTab === "mikro" || labSubTab === "cytohisto") && (
                    <Card className="mt-3"><CardContent className="p-4">
                      <div className="grid gap-3">
                        {(() => {
                          const items = (sel?.labsText||[]).filter((it) => {
                            const L = (it.lab||"").toLowerCase();
                            if (labSubTab === "genet") return L.includes("genet");
                            if (labSubTab === "mikro") return L.includes("mikro");
                            if (labSubTab === "cytohisto") return L.includes("cytolog") || L.includes("histolog");
                            return false;
                          });
                          if (items.length === 0) return <div className="text-sm text-slate-500">Žiadne textové výsledky v tejto kategórii.</div>;
                          return items.sort((a,b)=> b.date.localeCompare(a.date)).map((it,i)=> (
                            <div key={i} className="p-3 rounded-lg border" style={{ borderColor: COLORS.border }}>
                              <div className="flex items-center justify-between mb-1">
                                <div className="text-sm text-slate-500">{it.date}</div>
                                <Badge>{it.lab}</Badge>
                              </div>
                              <pre className="whitespace-pre-wrap text-sm leading-6 text-slate-700">{it.text}</pre>
                            </div>
                          ));
                        })()}
                      </div>
                    </CardContent></Card>
                  )}
                </TabsContent>

                {/* IMAGING (centered subtabs) */}
                <TabsContent value="imaging" current={mainTab}>
                  <div className="flex flex-wrap justify-center gap-2 mb-2 text-sm">
                    <TabsTrigger value="rtg" current={imagingSubTab} onClick={setImagingSubTab}>Röntgenové vyšetrenia</TabsTrigger>
                    <TabsTrigger value="usg" current={imagingSubTab} onClick={setImagingSubTab}>Ultrasonografické vyšetrenia</TabsTrigger>
                    <TabsTrigger value="ct" current={imagingSubTab} onClick={setImagingSubTab}>CT vyšetrenia</TabsTrigger>
                    <TabsTrigger value="mr" current={imagingSubTab} onClick={setImagingSubTab}>MR vyšetrenia</TabsTrigger>
                  </div>
                  <Card><CardContent className="p-0 overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Dátum</TableHead>
                          <TableHead>Typ</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {[...(sel?.imaging||[])]
                          .filter(img => {
                            const t = (img.type||"").toLowerCase();
                            if (imagingSubTab === "rtg") return t.includes("rtg");
                            if (imagingSubTab === "usg") return t.includes("usg");
                            if (imagingSubTab === "ct") return t.includes("ct");
                            if (imagingSubTab === "mr") return t.includes("mr");
                            return true;
                          })
                          .sort((a,b)=> b.date.localeCompare(a.date))
                          .map((r,i)=> (
                            <TableRow key={i}>
                              <TableCell className="font-medium">{r.date}</TableCell>
                              <TableCell>{r.type}</TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </CardContent></Card>
                </TabsContent>

                {/* PREPÚŠŤACIA SPRÁVA – single record, no filters */}
                <TabsContent value="discharge" current={mainTab}>
                  <Card><CardContent className="p-4">
                    <div className="text-sm text-slate-500">{sel?.discharges?.[0]?.date || "—"}</div>
                    <pre className="whitespace-pre-wrap text-sm leading-6 text-slate-700">{sel?.discharges?.[0]?.text || sel?.disch || "—"}</pre>
                  </CardContent></Card>
                </TabsContent>

                {/* EPIKRÍZA – placeholder */}
                <TabsContent value="epik" current={mainTab}>
                  <Card><CardContent className="p-4 space-y-2">
                    <pre className="whitespace-pre-wrap text-sm leading-6 text-slate-700">{`Epikríza: súhrn priebehu hospitalizácie a liečby. (Demo)`}</pre>
                    <div className="flex gap-2 justify-end">
                      <Button variant="outline">Uložiť lokálne</Button>
                      <Button style={{ background: COLORS.secondary }}>Exportovať do nemocničnej databázy</Button>
                    </div>
                  </CardContent></Card>
                </TabsContent>
              </div>
            </div>
          </div>
        </Overlay>
      )}
    </div>
  );
}
